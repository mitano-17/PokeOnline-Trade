const express=require('express');
const app=express();
const port=3000;
app.use(express.json());       
app.use(express.urlencoded({extended: true})); 
const bcrypt = require("bcrypt")
const mysql = require('mysql');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '123',
  database: 'pokemon'
});

/*connection.connect((err) => {
  if (err) throw err;
  console.log('Connected!');
});

use to communicate with server*/

app.get('/',(req,res)=>{
    app.use(express.static('views'));
    res.sendFile(__dirname+'/views/login.html')
})

app.get('/register',(req,res)=>{
 
    res.sendFile(__dirname+'/views/register.html')
})

app.post("/login.html",(req,res)=>{
const user=req.body.full_name;
const pass1=req.body.psw;
const pass2=req.body.psw2;
const num=req.body.phone;
const mail=req.body.email;
if(pass1==pass2)
{
  bcrypt.genSalt(10, (err, salt) => {
    bcrypt.hash(pass1, salt, function(err, hash) {
        connection.connect(function(err){
          if (err) 
            throw err;
          connection.query("SELECT * FROM ketchup WHERE relish="+user+";", function (err, result, fields) {
            console.log(result);
          if(result===undefined)
          {
            var sql = "INSERT INTO ketchup (relish,mayo,soysauce,vinegar) VALUES ('" +user+"','"+hash+"','"+mail+"','"+num+"');";
            connection.query(sql, function (err, result) {
              if (err)
                throw err;
              console.log("1 record inserted");
            });
          }

          else
          console.log("user is there already!");
  });
        })
       
    });
})
}
})

app.listen(port,()=>{
    console.log("App listening on port http://localhost:3000")
})

